term.redirect(peripheral.wrap("back"))
