term.redirect(peripheral.wrap("right"))
